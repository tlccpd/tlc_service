package com.store.web.front.key;


public class WebParamKey implements com.store.comp.control.key.WebParamKey {

}
