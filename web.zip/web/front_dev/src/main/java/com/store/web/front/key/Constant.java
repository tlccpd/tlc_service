package com.store.web.front.key;


public class Constant implements com.company.core.key.Constant,
								 com.store.comp.control.key.Constant{

}
