package com.store.web.front.dto;


public class Cache {

   
   private String group;
   private String user;
   private String category;
   
   
   public String getGroup() {
      return group;
   }
   
   public void setGroup(String group) {
      this.group = group;
   }
   
   public String getUser() {
      return user;
   }
   
   public void setUser(String user) {
      this.user = user;
   }
   
   public String getCategory() {
      return category;
   }
   
   public void setCategory(String category) {
      this.category = category;
   }
}
