package com.store.web.front.key;


public class WebAttrKey implements com.company.core.key.WebAttrKey {

}
